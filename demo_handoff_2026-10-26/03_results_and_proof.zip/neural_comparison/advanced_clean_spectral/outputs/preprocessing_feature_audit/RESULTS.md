# Preprocessing and compact-feature SVM audit

## Protocol

- 5 repeats x 5 participant-level outer folds, stratified by site and diagnosis.
- 4-fold training-only selection of feature family, site normalization, PCA, SVM C, and FTD class weight.
- Both preprocessing versions used identical participants and outer folds.
- Primary selection metric: macro F1; FTD recall was the first tie-breaker.

## Repeated cross-validation

| Model | Accuracy | Macro F1 | Macro recall | FTD recall |
|---|---:|---:|---:|---:|
| Minimal | 54.3% +/- 7.0 | 50.9% +/- 7.6 | 51.6% +/- 7.2 | 31.3% +/- 16.4 |
| Advanced | 51.6% +/- 7.7 | 48.9% +/- 8.0 | 49.6% +/- 7.8 | 34.8% +/- 18.7 |
| Fusion | 54.3% +/- 7.8 | 51.4% +/- 8.9 | 52.4% +/- 8.3 | 36.4% +/- 21.3 |

Advanced minus minimal cleaning changed macro F1 by -1.98 percentage points on average across paired folds.
It changed FTD recall by +3.56 percentage points.

## Pooled class results

| Model | AD F1 / recall | FTD F1 / recall | HC F1 / recall |
|---|---:|---:|---:|
| Minimal | 62.6% / 60.0% | 31.2% / 31.0% | 60.3% / 63.6% |
| Advanced | 60.6% / 58.0% | 32.4% / 34.8% | 55.8% / 55.7% |
| Fusion | 61.4% / 55.2% | 34.2% / 36.2% | 60.9% / 65.6% |

## Cleaning audit

- Advanced cleaning interpolated 238 channels across 114 of 174 participants.
- It removed 87 ICA components across 76 participants.
- It retained 6719 of 12577 artifact-free candidate windows after limiting each participant to 40 windows.

## Interpretation

- Fusion produced the highest repeated-fold macro F1 in this experiment.
- Channel interpolation is too frequent to treat as a harmless cleanup step; 114 of 174 participants were altered.
- Results remain limited by FTD sample size and site shift. The repeated-fold estimate is more credible than the repeatedly inspected fixed test split.
